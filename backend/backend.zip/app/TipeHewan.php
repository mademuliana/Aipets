<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipeHewan extends Model
{
    public function hewan(){
        return $this->hasMany(Hewan::class, 'spesies');
    }
}
